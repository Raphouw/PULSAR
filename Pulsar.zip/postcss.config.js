module.exports = {
  plugins: {
    "@tailwindcss/postcss": {}, // <--- C'est ici que ça change !
    autoprefixer: {},
  },
};