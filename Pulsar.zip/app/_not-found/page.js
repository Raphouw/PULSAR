export default function NotFoundPage() {
  return <h1>404 - Page non trouvée 😅</h1>;
}
